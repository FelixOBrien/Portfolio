var require = meteorInstall({"lib":{"blog.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// lib/blog.js                                                       //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
BlogPosts = new Mongo.Collection('blogposts');
///////////////////////////////////////////////////////////////////////

},"certificates.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// lib/certificates.js                                               //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Certificates = new Mongo.Collection('certificates');
///////////////////////////////////////////////////////////////////////

},"projects.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// lib/projects.js                                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Projects = new Mongo.Collection('projects');
///////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
let Email;
module.link("meteor/email", {
  Email(v) {
    Email = v;
  }

}, 2);
module.link("../lib/projects");
module.link("../lib/certificates");
module.link("../lib/blog");
Accounts.config({
  forbidClientAccountCreation: true
});
Meteor.methods({
  addProject: function (title, desc, url, category) {
    Projects.insert({
      title: title,
      desc: desc,
      category: category,
      created: new Date(),
      link: url
    });
  },
  addCertificate: function (title, desc, url, img) {
    Certificates.insert({
      title: title,
      desc: desc,
      created: new Date(),
      link: url,
      img: img
    });
  },
  sendEmail: function (name, subject, email, content) {
    process.env.MAIL_URL = Meteor.settings.MAIL_URL;
    Email.send({
      from: "admin@felixob.com",
      to: "fobcode@gmail.com",
      subject: name + " " + subject + " " + email,
      text: content
    });
  },
  postBlog: function (title, content) {
    BlogPosts.insert({
      title: title,
      content: content,
      created: new Date()
    });
  }
});
///////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2Jsb2cuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9jZXJ0aWZpY2F0ZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9wcm9qZWN0cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiQmxvZ1Bvc3RzIiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiQ2VydGlmaWNhdGVzIiwiUHJvamVjdHMiLCJNZXRlb3IiLCJtb2R1bGUiLCJsaW5rIiwidiIsIkFjY291bnRzIiwiRW1haWwiLCJjb25maWciLCJmb3JiaWRDbGllbnRBY2NvdW50Q3JlYXRpb24iLCJtZXRob2RzIiwiYWRkUHJvamVjdCIsInRpdGxlIiwiZGVzYyIsInVybCIsImNhdGVnb3J5IiwiaW5zZXJ0IiwiY3JlYXRlZCIsIkRhdGUiLCJhZGRDZXJ0aWZpY2F0ZSIsImltZyIsInNlbmRFbWFpbCIsIm5hbWUiLCJzdWJqZWN0IiwiZW1haWwiLCJjb250ZW50IiwicHJvY2VzcyIsImVudiIsIk1BSUxfVVJMIiwic2V0dGluZ3MiLCJzZW5kIiwiZnJvbSIsInRvIiwidGV4dCIsInBvc3RCbG9nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxTQUFTLEdBQUcsSUFBSUMsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFdBQXJCLENBQVosQzs7Ozs7Ozs7Ozs7QUNBQUMsWUFBWSxHQUFHLElBQUlGLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixjQUFyQixDQUFmLEM7Ozs7Ozs7Ozs7O0FDQUFFLFFBQVEsR0FBRyxJQUFJSCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsVUFBckIsQ0FBWCxDOzs7Ozs7Ozs7OztBQ0FBLElBQUlHLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsUUFBSjtBQUFhSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDRSxVQUFRLENBQUNELENBQUQsRUFBRztBQUFDQyxZQUFRLEdBQUNELENBQVQ7QUFBVzs7QUFBeEIsQ0FBbkMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSUUsS0FBSjtBQUFVSixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNHLE9BQUssQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFNBQUssR0FBQ0YsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrREYsTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVo7QUFBK0JELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaO0FBQW1DRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaO0FBUTNRRSxRQUFRLENBQUNFLE1BQVQsQ0FBZ0I7QUFDZEMsNkJBQTJCLEVBQUU7QUFEZixDQUFoQjtBQUlBUCxNQUFNLENBQUNRLE9BQVAsQ0FBZTtBQUNiQyxZQUFVLEVBQUUsVUFBU0MsS0FBVCxFQUFnQkMsSUFBaEIsRUFBc0JDLEdBQXRCLEVBQTJCQyxRQUEzQixFQUFvQztBQUcvQ2QsWUFBUSxDQUFDZSxNQUFULENBQWdCO0FBQ2JKLFdBQUssRUFBRUEsS0FETTtBQUViQyxVQUFJLEVBQUVBLElBRk87QUFHYkUsY0FBUSxFQUFFQSxRQUhHO0FBSWJFLGFBQU8sRUFBRSxJQUFJQyxJQUFKLEVBSkk7QUFLYmQsVUFBSSxFQUFFVTtBQUxPLEtBQWhCO0FBT0EsR0FYWTtBQVliSyxnQkFBYyxFQUFFLFVBQVNQLEtBQVQsRUFBZ0JDLElBQWhCLEVBQXNCQyxHQUF0QixFQUEyQk0sR0FBM0IsRUFBK0I7QUFFM0NwQixnQkFBWSxDQUFDZ0IsTUFBYixDQUFvQjtBQUNsQkosV0FBSyxFQUFFQSxLQURXO0FBRWxCQyxVQUFJLEVBQUVBLElBRlk7QUFHbEJJLGFBQU8sRUFBRSxJQUFJQyxJQUFKLEVBSFM7QUFJbEJkLFVBQUksRUFBRVUsR0FKWTtBQUtsQk0sU0FBRyxFQUFFQTtBQUxhLEtBQXBCO0FBVUgsR0F4Qlk7QUF5QmJDLFdBQVMsRUFBRSxVQUFTQyxJQUFULEVBQWVDLE9BQWYsRUFBd0JDLEtBQXhCLEVBQStCQyxPQUEvQixFQUF1QztBQUNoREMsV0FBTyxDQUFDQyxHQUFSLENBQVlDLFFBQVosR0FBdUIxQixNQUFNLENBQUMyQixRQUFQLENBQWdCRCxRQUF2QztBQUNBckIsU0FBSyxDQUFDdUIsSUFBTixDQUFXO0FBQ1RDLFVBQUksRUFBRSxtQkFERztBQUVUQyxRQUFFLEVBQUUsbUJBRks7QUFHVFQsYUFBTyxFQUFFRCxJQUFJLEdBQUcsR0FBUCxHQUFhQyxPQUFiLEdBQXVCLEdBQXZCLEdBQTZCQyxLQUg3QjtBQUlUUyxVQUFJLEVBQUVSO0FBSkcsS0FBWDtBQU1ELEdBakNZO0FBa0NiUyxVQUFRLEVBQUUsVUFBU3RCLEtBQVQsRUFBZ0JhLE9BQWhCLEVBQXdCO0FBQ2hDNUIsYUFBUyxDQUFDbUIsTUFBVixDQUFpQjtBQUNmSixXQUFLLEVBQUVBLEtBRFE7QUFFZmEsYUFBTyxFQUFFQSxPQUZNO0FBR2ZSLGFBQU8sRUFBRSxJQUFJQyxJQUFKO0FBSE0sS0FBakI7QUFLRDtBQXhDWSxDQUFmLEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIkJsb2dQb3N0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdibG9ncG9zdHMnKTtcbiIsIkNlcnRpZmljYXRlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjZXJ0aWZpY2F0ZXMnKTtcbiIsIlByb2plY3RzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3Byb2plY3RzJyk7XG5cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSdcbmltcG9ydCB7IEVtYWlsIH0gZnJvbSAnbWV0ZW9yL2VtYWlsJztcbmltcG9ydCBcIi4uL2xpYi9wcm9qZWN0c1wiO1xuaW1wb3J0IFwiLi4vbGliL2NlcnRpZmljYXRlc1wiO1xuaW1wb3J0IFwiLi4vbGliL2Jsb2dcIjtcblxuXG5BY2NvdW50cy5jb25maWcoe1xuICBmb3JiaWRDbGllbnRBY2NvdW50Q3JlYXRpb246IHRydWVcbn0pO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gIGFkZFByb2plY3Q6IGZ1bmN0aW9uKHRpdGxlLCBkZXNjLCB1cmwsIGNhdGVnb3J5KXtcbiBcblxuICAgUHJvamVjdHMuaW5zZXJ0KHtcbiAgICAgIHRpdGxlOiB0aXRsZSxcbiAgICAgIGRlc2M6IGRlc2MsXG4gICAgICBjYXRlZ29yeTogY2F0ZWdvcnksXG4gICAgICBjcmVhdGVkOiBuZXcgRGF0ZSgpLCBcbiAgICAgIGxpbms6IHVybFxuICAgIH0pO1xuICB9LFxuICBhZGRDZXJ0aWZpY2F0ZTogZnVuY3Rpb24odGl0bGUsIGRlc2MsIHVybCwgaW1nKXtcbiAgXG4gICAgICBDZXJ0aWZpY2F0ZXMuaW5zZXJ0KHtcbiAgICAgICAgdGl0bGU6IHRpdGxlLFxuICAgICAgICBkZXNjOiBkZXNjLFxuICAgICAgICBjcmVhdGVkOiBuZXcgRGF0ZSgpLCBcbiAgICAgICAgbGluazogdXJsLFxuICAgICAgICBpbWc6IGltZ1xuICAgICAgfSk7XG4gICBcbiBcblxuICB9LFxuICBzZW5kRW1haWw6IGZ1bmN0aW9uKG5hbWUsIHN1YmplY3QsIGVtYWlsLCBjb250ZW50KXtcbiAgICBwcm9jZXNzLmVudi5NQUlMX1VSTCA9IE1ldGVvci5zZXR0aW5ncy5NQUlMX1VSTDtcbiAgICBFbWFpbC5zZW5kKHtcbiAgICAgIGZyb206IFwiYWRtaW5AZmVsaXhvYi5jb21cIixcbiAgICAgIHRvOiBcImZvYmNvZGVAZ21haWwuY29tXCIsXG4gICAgICBzdWJqZWN0OiBuYW1lICsgXCIgXCIgKyBzdWJqZWN0ICsgXCIgXCIgKyBlbWFpbCxcbiAgICAgIHRleHQ6IGNvbnRlbnRcbiAgICAgIH0pO1xuICB9LFxuICBwb3N0QmxvZzogZnVuY3Rpb24odGl0bGUsIGNvbnRlbnQpe1xuICAgIEJsb2dQb3N0cy5pbnNlcnQoe1xuICAgICAgdGl0bGU6IHRpdGxlLFxuICAgICAgY29udGVudDogY29udGVudCxcbiAgICAgIGNyZWF0ZWQ6IG5ldyBEYXRlKClcbiAgICB9KVxuICB9XG59KTtcbiJdfQ==
